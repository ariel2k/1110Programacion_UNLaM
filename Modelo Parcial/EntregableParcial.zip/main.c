#include "main.h"


int main(void)
{
    t_colaC colaC;
    t_arbol arbol;
    FILE  *fpStock;

    crearColaC(&colaC);
    crearArbol(&arbol);

/** esta funci�n es necesaria para crear el maestro de productos y el �rbol
 *      de �ndices del archivo, adem�s carga la lista de pedidos en la cola
 *      a medida que los muestra
 */
    crearArchivoCargarListaCargarArbol(&colaC, &arbol);

/** la apertura del archivo ya est� resuelta */
    if(!abrirArchivo(&fpStock, ARCH_NOM, "r+b", CON_MSJ))
    {
        fprintf(stderr, "El programa se cancela.\n");
        return 1;
    }
/** las siguientes funciones se encargan de mostrar el archivo y el �rbol  */
    mostrarArchivo(fpStock);
    mostrarArbolEnPreorden(&arbol, mostrarTInfoArbol);

/** las siguientes funciones deben ser reemplazadas por nuevas versiones
 *      al efecto puede escribir sus prototipos al comienzo de main y sus
 *      desarrollos al final de main.
 *  puede utilizar todas las primitivas salvo las que tienen sufijo _2
 */
    sacarDeColaCBuscarEnArbolActualizarArchivo_2(&colaC, &arbol, fpStock);
    mostrarFaltantesYReposicion_2(fpStock);
/** las siguientes funciones le permiten comprobar si el resultado es el
 *      el esperado, adem�s de vaciar el arbol y cerrar el archivo
 */
    mostrarArchivo(fpStock);
    vaciarArbol(&arbol);
    fclose(fpStock);

    return 0;
}
